public class Main {
    public static void main(String[] args) {
        // Kick off the program.
        MultiThread multiThread = new MultiThread();

//        ComPort comPort = new ComPort();
//        comPort.initialize();
//        ArduinoOut arduinoOut = new ArduinoOut(comPort);
//        ArduinoIn arduinoIn = new ArduinoIn(comPort);
//
//        Thread t1 = new Thread(arduinoOut);
//        Thread t2 = new Thread(arduinoIn);
//        t1.start();
//        t2.start();
    }
}
